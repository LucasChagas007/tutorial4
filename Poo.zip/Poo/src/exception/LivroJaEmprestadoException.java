package exception;
import biblioteca.Livro;

public class LivroJaEmprestadoException extends Exception {
    public LivroJaEmprestadoException(Livro livro) {
        super(livro + " já está emprestado!");
    }
}
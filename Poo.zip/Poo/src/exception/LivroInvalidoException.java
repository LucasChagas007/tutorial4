package exception;

public class LivroInvalidoException extends Exception {
    public LivroInvalidoException() {
        super("Livro não pode ser nulo!");
    }
}
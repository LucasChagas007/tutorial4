package exception;
import biblioteca.Livro;

public class LivroNaoEmPosseException extends Exception {
    public LivroNaoEmPosseException(Livro livro) {
        super(livro + " não está em sua posse e não pode ser devolvido!");
    }
}
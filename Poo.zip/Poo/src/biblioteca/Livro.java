package biblioteca;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.Objects;

public class Livro implements Comparable<Livro> {
    private String isbn;
    private String titulo;
    private LocalDate dataPublicacao;

    public Livro(String isbn, String titulo, LocalDate dataPublicacao) {
        this.isbn = isbn;
        this.titulo = titulo;
        this.dataPublicacao = dataPublicacao;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getTitulo() {
        return titulo;
    }

    public LocalDate getDataPublicacao() {
        return dataPublicacao;
    }

    @Override
    public String toString() {
        return titulo + " (" + dataPublicacao.getYear() + ")" + " [" + isbn + "]";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Livro)) return false;
        Livro outro = (Livro) o;
        return isbn.equals(outro.isbn);
    }
    @Override
    public int hashCode() {
        return Objects.hash(isbn);
    }


    @Override
    public int compareTo(Livro outro) {
        return this.titulo.compareTo(outro.titulo);
    }


    public static Comparator<Livro> dataPublicacao() {
        return Comparator.comparing(Livro::getDataPublicacao);
    }
}
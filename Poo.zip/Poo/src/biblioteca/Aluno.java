package biblioteca;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;


import exception.EmprestimosExcedidoException;
import exception.LivroInvalidoException;
import exception.LivroJaEmprestadoException;
import exception.LivroNaoEmPosseException;

public class Aluno implements Comparable<Aluno> {
	private String matricula;
	private String nome;
	private List<Livro> emprestimos = new ArrayList<>();
	
	
	public Aluno(String matricula, String nome) {
		this.matricula = matricula;
		this.nome = nome;
	}
	public String getMatricula() {
		return matricula;
	}
	public String getNome() {
		return nome;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	@Override
	public String toString() {
		return nome + " (" + matricula+ ")";
	}
	
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Aluno)) return false;
        Aluno a = (Aluno) o;
        return matricula == a.matricula && Objects.equals(nome, a.nome);
    }

    @Override
    public int hashCode() { 
    	return Objects.hash(nome, matricula); 
    }


    public int compareTo(Aluno other) {
        // Ordenação natural por matrícula
        return this.matricula.compareTo(other.matricula);
    }

    /**
     * Comparator para ordenação de Aluno por nome, eliminando duplicatas por matrícula.
     */
    public static Comparator<Aluno> comparadorNome() {
        return new Comparator<Aluno>() {
            @Override
            public int compare(Aluno a1, Aluno a2) {
                // elimina duplicatas por matrícula
                if (a1.getMatricula().equals(a2.getMatricula())) {
                    return 0;
                }
                // ordena por nome
                return a1.getNome().compareTo(a2.getNome());
            }
        };
    }
    
    public void emprestar(Livro livro)
            throws LivroInvalidoException, EmprestimosExcedidoException, LivroJaEmprestadoException {
        if (livro == null) {
            throw new LivroInvalidoException();
        }
        if (emprestimos.size() >= 3) {
            throw new EmprestimosExcedidoException();
        }
        if (emprestimos.contains(livro)) {
            throw new LivroJaEmprestadoException(livro);
        }
        emprestimos.add(livro);
    }

    public void renovar(Livro livro) 
            throws LivroInvalidoException, LivroNaoEmPosseException {
        if (livro == null) {
            throw new LivroInvalidoException();
        }
        if (!emprestimos.contains(livro)) {
            throw new LivroNaoEmPosseException(livro);
        }
        // …
    }

    public void devolver(Livro livro) 
            throws LivroInvalidoException, LivroNaoEmPosseException {
        if (livro == null) {
            throw new LivroInvalidoException();
        }
        if (!emprestimos.contains(livro)) {
            throw new LivroNaoEmPosseException(livro);
        }
        emprestimos.remove(livro);
    }
	
}
